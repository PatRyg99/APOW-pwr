
Chess Pieces - v23 raw
==============================

This dataset was exported via roboflow.ai on February 23, 2021 at 5:28 PM GMT

It includes 289 images.
Pieces are annotated in COCO format.

The following pre-processing was applied to each image:

No image augmentation techniques were applied.


